<?php

namespace Wutime\UserHideAvatars\XF\Entity;

use XF\Mvc\Entity\Structure;

class User extends XFCP_User
{
	
}