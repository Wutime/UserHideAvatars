<?php

// ################## THIS IS A GENERATED FILE ##################
// DO NOT EDIT DIRECTLY. EDIT THE CLASS EXTENSIONS IN THE CONTROL PANEL.

namespace Wutime\UserHideAvatars\XF\Entity
{
	class XFCP_UserOption extends \XF\Entity\UserOption {}
}

namespace Wutime\UserHideAvatars\XF\Pub\Controller
{
	class XFCP_Account extends \XF\Pub\Controller\Account {}
}