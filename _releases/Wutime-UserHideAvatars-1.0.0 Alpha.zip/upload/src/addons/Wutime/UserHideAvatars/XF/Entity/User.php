<?php

namespace Wutime\UserHideAvatars\XF\Entity;

use XF\Mvc\Entity\Structure;

/**
 * COLUMNS
 * @property int user_id
 * @property bool show_dob_year
 * @property bool show_dob_date
 * @property bool content_show_signature
 * @property bool receive_admin_email
 * @property bool email_on_conversation
 * @property bool push_on_conversation
 * @property bool is_discouraged
 * @property string creation_watch_state
 * @property string interaction_watch_state
 * @property array alert_optout
 * @property array push_optout
 * @property bool use_tfa
 *
 * RELATIONS
 * @property \XF\Mvc\Entity\AbstractCollection|\XF\Entity\UserAlertOptOut[] AlertOptOut
 * @property \XF\Mvc\Entity\AbstractCollection|\XF\Entity\UserPushOptOut[] PushOptOut
 * @property \XF\Entity\User User
 */

class User extends XFCP_User
{
/*
	public static function getStructure(Structure $structure)
	{
		$structure = parent::getStructure($structure);

		$structure->columns += ['wutime_userhideavatars_enable' => ['type' => self::BOOL, 'default' => false]];

		return $structure;
	}

	protected function _setupDefaults()
	{
		$options = \XF::options();

		$defaults = $options->registrationDefaults;
		$this->wutime_userhideavatars_enable = $defaults['wutime_userhideavatars_enable'] ? true : false;
	}
*/
}